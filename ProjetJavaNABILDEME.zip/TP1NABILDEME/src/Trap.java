import java.awt.Image;

public class Trap extends SolidThings {

    public Trap(int x, int y, Image image) {
        super(x, y, image);
    }
}
