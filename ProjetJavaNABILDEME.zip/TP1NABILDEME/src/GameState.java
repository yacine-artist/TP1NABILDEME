public enum GameState {
    TITLE_SCREEN,
    PLAYING,
    GAME_OVER
}
