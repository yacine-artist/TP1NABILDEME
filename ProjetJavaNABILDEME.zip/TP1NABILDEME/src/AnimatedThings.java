import java.awt.Image;

public class AnimatedThings extends SolidThings {
    public AnimatedThings(int x, int y, Image image) {
        super(x, y, image);
    }
}