import java.awt.Graphics;
import java.awt.Image;

public class SolidThings extends Things {
    private Hitbox hitBox;

    public SolidThings(int x, int y, Image image) {
        super(x, y, image);
        hitBox = new Hitbox(x, y, width, height);
    }

    public Hitbox getHitBox() {
        return hitBox;
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
    }
}