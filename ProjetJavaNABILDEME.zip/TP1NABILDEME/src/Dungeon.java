import java.util.ArrayList;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Dungeon {

    private ArrayList<Things> renderList = new ArrayList<>();
    private char[][] map;
    private int width;
    private int height;
    private TileManager tileManager;

    public Dungeon(String fileName, TileManager tileManager) {
        this.tileManager = tileManager;

        try {
            loadMap(fileName);
            buildMap();
        } catch (IOException e) {
            System.out.println("Erreur map : " + e.getMessage());
            width = 10;
            height = 10;
            map = new char[width][height];
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    if (x == 0 || y == 0 || x == width - 1 || y == height - 1) {
                        map[x][y] = 'W';
                    } else {
                        map[x][y] = ' ';
                    }
                }
            }
            buildMap();
        }
    }

    private void loadMap(String fileName) throws IOException {
        ArrayList<String> lines = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = br.readLine()) != null) {
            if (!line.trim().isEmpty()) {
                lines.add(line);
            }
        }
        br.close();

        if (lines.isEmpty()) {
            throw new IOException("Fichier vide");
        }

        width = 0;
        for (String l : lines) {
            if (l.length() > width) {
                width = l.length();
            }
        }
        height = lines.size();
        map = new char[width][height];

        for (int y = 0; y < height; y++) {
            String l = lines.get(y);
            for (int x = 0; x < width; x++) {
                if (x < l.length()) {
                    map[x][y] = l.charAt(x);
                } else {
                    map[x][y] = ' ';
                }
            }
        }
    }

    private void buildMap() {
        renderList.clear();

        int tileSizeW = tileManager.getWidth();
        int tileSizeH = tileManager.getHeight();

        Image grass = tileManager.getTile(0, 0);
        Image path  = tileManager.getTile(1, 0);
        Image wallTree1 = tileManager.getTile(0, 12);
        Image wallTree2 = tileManager.getTile(1, 12);
        Image trapSpikes = tileManager.getTile(4, 3);
        Image trapAlt = tileManager.getTile(2, 3);

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {

                int px = x * tileSizeW;
                int py = y * tileSizeH;
                char c = map[x][y];

                if (c == 'D') {
                    renderList.add(new Things(px, py, path));
                } else {
                    renderList.add(new Things(px, py, grass));
                }

                if (c == 'W') {
                    boolean variant = (x + y) % 2 == 0;
                    Image wallImage = variant ? wallTree1 : wallTree2;
                    renderList.add(new SolidThings(px, py, wallImage));
                }

                if (c == 'T') {
                    Image trapImage = (trapSpikes != null) ? trapSpikes : trapAlt;
                    renderList.add(new Trap(px, py, trapImage));
                }

                if (c == 'F') {
                    Image flower = tileManager.getTile(3, 0);
                    renderList.add(new Things(px, py, flower));
                }

                if (c == 'O') {
                    Image water = tileManager.getTile(4, 0);
                    renderList.add(new SolidThings(px, py, water));
                }
            }
        }
    }

    public ArrayList<Things> getRenderList() {
        return renderList;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
