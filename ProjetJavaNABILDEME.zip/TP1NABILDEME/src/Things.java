import java.awt.Graphics;
import java.awt.Image;

public class Things {
    public int x, y;
    public int width, height;
    public Image image;

    public Things(int x, int y, Image image) {
        this.x = x;
        this.y = y;
        this.image = image;
        if (image != null) {
            this.width = image.getWidth(null);
            this.height = image.getHeight(null);
        }
    }

    public void draw(Graphics g) {
        if (image != null) {
            g.drawImage(image, x, y, null);
        }
    }
}
