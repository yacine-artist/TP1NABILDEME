import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;

public class Hero extends DynamicThings {
    private static Hero instance;
    private int maxHealth = 100;
    private int currentHealth = 100;
    private boolean isAlive = true;
    private long lastDamageTime = 0;
    private static final long INVINCIBILITY_DURATION = 2000; // 2 secondes

    private Hero(int x, int y, Image image) {
        super(x, y, image);
    }

    public static Hero getInstance() {
        if (instance == null) {
            instance = new Hero(0, 0, null);
        }
        return instance;
    }

    public void takeDamage(int damage) {
        long currentTime = System.currentTimeMillis();

        if (currentTime - lastDamageTime < INVINCIBILITY_DURATION) {
            return;
        }

        currentHealth -= damage;
        lastDamageTime = currentTime;

        System.out.println("💔 Dégâts : " + damage + " | Vie : " + currentHealth + "/" + maxHealth);

        if (currentHealth <= 0) {
            currentHealth = 0;
            isAlive = false;
            System.out.println("☠️ GAME OVER !");
        }
    }

    public boolean isInvincible() {
        long currentTime = System.currentTimeMillis();
        return (currentTime - lastDamageTime) < INVINCIBILITY_DURATION;
    }

    public int getCurrentHealth() { return currentHealth; }
    public int getMaxHealth() { return maxHealth; }
    public boolean isAlive() { return isAlive; }

    public void reset(int x, int y) {
        this.x = x;
        this.y = y;
        this.currentHealth = maxHealth;
        this.isAlive = true;
        this.lastDamageTime = 0;
        this.setSpeedX(0);
        this.setSpeedY(0);
    }

    @Override
    public void draw(Graphics g) {
        // Clignotement si invincible
        if (isInvincible()) {
            long elapsed = System.currentTimeMillis() - lastDamageTime;
            if ((elapsed / 100) % 2 == 0) {
                super.draw(g);
            }
        } else {
            super.draw(g);
        }

        drawHealthBar(g);
    }

    private void drawHealthBar(Graphics g) {
        int barWidth = 32;
        int barHeight = 4;
        int barX = x;
        int barY = y - 8;

        g.setColor(Color.RED);
        g.fillRect(barX, barY, barWidth, barHeight);

        int healthWidth = (int) ((double) currentHealth / maxHealth * barWidth);
        g.setColor(Color.GREEN);
        g.fillRect(barX, barY, healthWidth, barHeight);

        g.setColor(Color.BLACK);
        g.drawRect(barX, barY, barWidth, barHeight);
    }
}
