import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

public class GameRender extends JPanel {
    private Dungeon dungeon;
    private Hero hero;
    private GameState gameState;

    public GameRender(Dungeon dungeon, Hero hero, GameState gameState) {
        this.dungeon = dungeon;
        this.hero = hero;
        this.gameState = gameState;
    }

    public void setGameState(GameState gameState) {
        this.gameState = gameState;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // ÉCRAN TITRE
        if (gameState == GameState.TITLE_SCREEN) {
            drawTitleScreen(g);
            return;
        }

        // ÉCRAN DE JEU
        // 1. Donjon
        for (Things thing : dungeon.getRenderList()) {
            thing.draw(g);
        }

        // 2. Héros
        hero.draw(g);

        // 3. Vie globale en haut à droite
        String healthText = "❤ " + hero.getCurrentHealth() + "/" + hero.getMaxHealth();
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString(healthText, getWidth() - 120, 20);

        // 4. Game Over
        if (!hero.isAlive()) {
            drawGameOver(g);
        }
    }

    private void drawTitleScreen(Graphics g) {
        // Fond noir
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Titre du jeu
        g.setColor(new Color(255, 215, 0)); // Or
        g.setFont(new Font("Arial", Font.BOLD, 60));
        String title = "MON SUPER JEU";
        int titleWidth = g.getFontMetrics().stringWidth(title);
        g.drawString(title, (getWidth() - titleWidth) / 2, getHeight() / 2 - 50);

        // Sous-titre
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 24));
        String subtitle = "Aventure dans le labyrinthe";
        int subtitleWidth = g.getFontMetrics().stringWidth(subtitle);
        g.drawString(subtitle, (getWidth() - subtitleWidth) / 2, getHeight() / 2 + 10);

        // Instruction clignotante
        long time = System.currentTimeMillis();
        if ((time / 500) % 2 == 0) { // Clignote toutes les 500ms
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Arial", Font.BOLD, 28));
            String start = "Appuyez sur ESPACE pour commencer";
            int startWidth = g.getFontMetrics().stringWidth(start);
            g.drawString(start, (getWidth() - startWidth) / 2, getHeight() / 2 + 100);
        }

        // Crédits
        g.setColor(Color.GRAY);
        g.setFont(new Font("Arial", Font.PLAIN, 14));
        String credits = "TP3 - Développement Java";
        int creditsWidth = g.getFontMetrics().stringWidth(credits);
        g.drawString(credits, (getWidth() - creditsWidth) / 2, getHeight() - 30);
    }

    private void drawGameOver(Graphics g) {
        // Fond semi-transparent noir
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRect(0, 0, getWidth(), getHeight());

        // Texte "GAME OVER"
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        String gameOver = "GAME OVER";
        int textWidth = g.getFontMetrics().stringWidth(gameOver);
        g.drawString(gameOver, (getWidth() - textWidth) / 2, getHeight() / 2);

        // Instructions
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 20));
        String restart = "Appuyez sur R pour recommencer";
        int restartWidth = g.getFontMetrics().stringWidth(restart);
        g.drawString(restart, (getWidth() - restartWidth) / 2, getHeight() / 2 + 50);
    }
}
